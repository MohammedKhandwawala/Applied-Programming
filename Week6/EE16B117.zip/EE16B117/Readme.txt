name : Mohammed Khandwawala
roll no: ee16b117

Sourcecodev1 contains regular model with position of collision between iteration is a unifor random variable between 0 and 1.

Sourcecodev2 contains the modified version to that model where time is a uniform random variable and position of of collision is obtained using equation of motion. 

The Latex file Main.tex can be run by using xelatex

To run type in terminal in file location
>> xelatex Main.tex 

or latex can be used but the desired output is not as good
>> latex Main.tex

Output pdf , plots and source code is attached

xelatex if not instaled it can be installed by
>> sudo apt-get install xelatex


