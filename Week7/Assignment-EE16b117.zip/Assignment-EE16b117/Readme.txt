name : Mohammed Khandwawala
roll no: ee16b117

The Latex file Main.txt can be run by using xelatex

To run type in terminal in file location
>> xelatex Main.tex 

or latex can be used but the desired output is not as good
>> latex Main.tex

Output pdf , plots and source code is attached

xelatex if not instaled it can be installed by
>> sudo apt-get install xelatex
